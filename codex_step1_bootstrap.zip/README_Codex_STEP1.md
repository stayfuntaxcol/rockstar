# Codex STEP 1 — Bootstrap + Login (React + Tailwind + Firebase)

Volg exact deze stappen in je `rockstar` repo (Codespaces/VS Code). Dit is de **minimaal werkende login**.
Als je repo nog geen Vite React project heeft, dit plan maakt er één. Zo niet: kopieer alleen de `src/` en config-bestanden die nog ontbreken.

## 1) Nieuwe branch
```bash
git checkout -b feat/bootstrap
```

## 2) Vite + dependencies installeren
```bash
npm create vite@latest . -- --template react-ts
npm i firebase react-router-dom
npm i -D tailwindcss postcss autoprefixer @tailwindcss/forms @tailwindcss/typography
npx tailwindcss init -p
```

## 3) Bestanden uit deze bundle plaatsen
- Plaats `tailwind.config.js` in je repo-root (overschrijven oké).
- Plaats `firebase.json` en `.firebaserc` in je repo-root (als je nog niet met Firebase Hosting werkt is dit alvast klaar).
- Maak folders als ze nog niet bestaan: `src/lib`, `src/features/auth`, `src`.
- Kopieer alle `src/*` uit deze bundle naar jouw `src/` (overschrijven oké).
- Kopieer `index.html` alleen als je nog de Vite default hebt; anders laat je je eigen staan.

## 4) Env variabelen aanmaken
Maak `.env.local` in je repo-root met deze inhoud (al bekend uit jouw project):
```
VITE_FIREBASE_API_KEY=AIzaSyDWjt0YeuEhUCMMOKToGUhjq21K8HlZ8Fk
VITE_FIREBASE_AUTH_DOMAIN=rock-f5937.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=rock-f5937
VITE_FIREBASE_STORAGE_BUCKET=rock-f5937.firebasestorage.app
VITE_FIREBASE_MESSAGING_SENDER_ID=1066836195707
VITE_FIREBASE_APP_ID=1:1066836195707:web:153c8721f8cf0510af65de
VITE_FIREBASE_MEASUREMENT_ID=G-SLZXLRZMCG
```

## 5) Firebase Console
- Auth → Sign-in method → **Email/Password**: **Enable**.
- Voeg 1 testuser toe (email + wachtwoord).

## 6) Run & test
```bash
npm run dev
```
Open de lokale URL → log in met je testuser → je ziet een eenvoudige **Welkom** pagina (ingelogd state).

## 7) Commit & PR
```bash
git add .
git commit -m "STEP1: Bootstrap + Tailwind + Firebase init + Sign-In"
git push -u origin feat/bootstrap
```
Maak een Pull Request naar `main`.

---

## Wat zit er in deze bundle?
- `tailwind.config.js` — met design tokens.
- `firebase.json`, `.firebaserc` — hosting + firestore config placeholders.
- `src/lib/firebase.ts` — init + offline persistence.
- `src/App.tsx`, `src/main.tsx`, `src/index.css` — minimaal AppShell.
- `src/features/auth/SignIn.tsx` — eenvoudige login.
- `index.html` — Vite entry (alleen gebruiken als je nog de default hebt).

Als dit live is, doen we **STEP 2** (Firestore rules + collections + Pipeline skeleton).
